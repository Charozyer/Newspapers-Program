﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agents
{
    public partial class Main : Form
    {
        Model1 db = new Model1();
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            db.AgentType.Select(a => new AgentType { id = a.ID, name = a.Title }).OrderBy(a => a.name).ToList(); //Сортировка типов агентов по имени
            agentTypeBindingSource.DataSource = db.AgentType.ToList(); //Загрузка типов агентов из БД для отображения в DataGridView
            agentBindingSource.DataSource = db.Agent.ToList(); //Загрузка агентов из БД для отображения в DataGridView

        }

        private void agentBindingSource_CurrentChanged(object sender, EventArgs e) // событие при выделении агента из списка
        {
            Agent agent = (Agent)agentBindingSource.Current; //передача локальной переменной агента из БД
            try //проверка на исключения
            {
                if (agent == null) return; //проверка на наличие выделенного агента, без нее программа будет вылетать
                if (agent.Logo != null) //проверка на наличие изображения агента
                {
                    //string str = agent.Logo.Substring(1); //Получение строки пути к изображению агрента
                    LogoPict.Image = Image.FromFile(agent.Logo); //отображение изображения агента в окне
                }
                else //если изображения агента нет
                {
                    LogoPict.Image = Image.FromFile("agents\\picture.png"); //загрузка общего изображения для агентов без него
                }
            }
            catch (Exception ex) //получение исключения если программа его выдаст
            {
                MessageBox.Show(ex.Message); //отображение окна с описанием исключения
            }
        }
        class AgentType
        {
            public int id { get; set; }
            public string name { get; set; }
        }

        private void removeSortButton_Click(object sender, EventArgs e) //кнопка для отображения исходных данных об агентах
        {
            agentBindingSource.DataSource = null;
            agentBindingSource.DataSource = db.Agent.ToList<Agent>();
        }

        private void sortPriorityButton_Click(object sender, EventArgs e) //кнопка сортировки по приоритету
        {
            if (checkBox1.Checked) //если флаг "По убыванию" установлен
            {
                agentBindingSource.DataSource = db.Agent.OrderByDescending(x => x.Priority).ToList();
            }
            else //если флаг "По убыванию" не установлен
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(x => x.Priority).ToList();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //изменения значения фильтра ComboBox
        {
            if (comboBox1.SelectedIndex < 0) return; // если индекс 0, ничего не делать
            int n = (int)comboBox1.SelectedValue; // передача выделеннного индекса в переменную
            List<Agent> agent = db.Agent.Where(a => a.AgentTypeID == n).ToList(); //Создание списка значений, где AgentTypeID равен выбранному в ComboBox
            agentBindingSource.DataSource = agent; //Отображения списка в элементе DataGridView
        }

        private void sortTypeButton_Click(object sender, EventArgs e) //кнопка сортировки по типу агента
        {
            if (checkBox1.Checked) //если флаг "По убыванию" установлен
            {
                agentBindingSource.DataSource = db.Agent.OrderByDescending(x => x.AgentTypeID).ToList();
            }
            else //если флаг "По убыванию" не установлен
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(x => x.AgentTypeID).ToList();
            }
        }

        private void addButton_Click(object sender, EventArgs e) //кнопка добавления агента
        {
            Agent agent = (Agent)agentBindingSource.Current; //вызов таблицы из БД
            Edit form = new Edit(); //создание локальной переменной для перехода в форму Edit
            DialogResult dr = form.ShowDialog(); // переход в Edit
            if (dr == DialogResult.OK) //если форма Edit вернула положительное значение
            {

                agentBindingSource.DataSource = db.Agent.ToList<Agent>(); //перезагрузка списка агентов
            }
        }

        private void editButton_Click(object sender, EventArgs e) //кнопка изменения агента
        {
            Agent agent = (Agent) agentBindingSource.Current; //вызов таблицы из БД
            Edit form = new Edit();//создание локальной переменной для перехода в форму Edit
            form.db = db; //передача значения из модели в локальную переменную
            form.agent = agent; //передача значения из модели в локальную переменную
            DialogResult dr = form.ShowDialog(); // переход в Edit
            if (dr == DialogResult.OK) //если форма Edit вернула положительное значение
            {

                agentBindingSource.DataSource = db.Agent.ToList<Agent>();//перезагрузка списка агентов
            }
        }

        private void delButton_Click(object sender, EventArgs e) //кнопка удаления агента
        {
            Agent agent = (Agent)agentBindingSource.Current; //вызов таблицы из БД
            DialogResult dr = MessageBox.Show("Удалить запись?" + agent.ID + "?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Question); //отображение диалогового окна с названием удаляемого агента
            if (dr == DialogResult.Yes) //если диалог вернул положительное значение
            {
                db.Agent.Remove(agent); //удаление агента
            }
            try //проверка на исключения
            {
                db.SaveChanges(); //сохранение изменений в таблице БД
                agentBindingSource.DataSource = db.Agent.ToList(); //перезагрузка списка агентов
            }
            catch (Exception ex) //получение исключения если программа его выдаст
            {
                MessageBox.Show(ex.Message);//отображение окна с описанием исключения
            }
        }
    } 
}

