﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agents
{
    public partial class Edit : Form
    {
        public Model1 db { get; set; }
        public Agent agent { get; set; }
        public Edit()
        {
            InitializeComponent();
        }

        private void Edit_Load(object sender, EventArgs e)
        {
            if (agent == null) // если форма не получила информацию об агенте
            {
                agentBindingSource.AddNew();//добавление новой записи в БД
                this.Text = "Добавление новой учетной записи"; //изменение названия формы
            }
            else // если форма получила информацию об агенте
            {
                agentBindingSource.Add(agent); //изменение выбранной записи из БД
                this.Text = "Изменение учетной записи"; //изменение названия формы
            }
        }

        private void saveButton_Click(object sender, EventArgs e) //нажатие на кнопку "Сохранить"
        {
            if (agent == null) // если форма не получила информацию об агенте
            {
                agent = (Agent)agentBindingSource.Current; //вызов таблицы из БД
                db.Agent.Add(agent); //добавление новой записи в БД
            }
            try //проверка на исключения
            {
                db.SaveChanges(); //сохранение изменений в таблице БД
                DialogResult = DialogResult.OK; //положительный ответ для формы Main
            }
            catch (Exception ex) //получение исключения если программа его выдаст
            {
                MessageBox.Show(ex.Message);//отображение окна с описанием исключения
            }
        }

        private void exitButton_Click(object sender, EventArgs e) //нажатие на кнопку "Выйти"
        {
            DialogResult = DialogResult.Cancel; //отрицательный ответ для формы Main
        }
    }
}
